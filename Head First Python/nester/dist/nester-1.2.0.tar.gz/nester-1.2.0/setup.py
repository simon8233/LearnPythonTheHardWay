from distutils.core import setup

setup(

        name         = 'nester',
        version      = '1.2.0',
        py_modules   = ['nester'],
        author       = 'jonathan',
        auther_email = 'jonathan@headfirstlabs.com',
        url          = 'http://github.com/simon8233',
        description  = 'A simple printer of nested lists',

    )

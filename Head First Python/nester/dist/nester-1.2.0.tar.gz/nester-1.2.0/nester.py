# -*- encoding=UTF-8 -*-
from __future__ import print_function
def print_recursive (print_object,need_tabs_in_print=0):
    """ This is a function , print multiple list in list."""
    for iter_obj in print_object:        
        if isinstance(iter_obj,list):
            print_recursive(iter_obj,need_tabs_in_print+1)
        else: 
            for i in range(need_tabs_in_print):
                print("\t", end='')
            print(iter_obj)

#case = ['movie',['apple',['aa','bb'],'banana'],'orange']
#print_recursive(case,2)
#print_recursive(case)
#print_recursive(case,-9)

# -*- encoding=UTF-8 -*-

def print_recursive (print_object):
""" This is a function , print multiple list in list."""
    for iter_obj in print_object:        
        if isinstance(iter_obj,list):
            print_recursive(iter_obj)
        else: 
            print iter_obj



